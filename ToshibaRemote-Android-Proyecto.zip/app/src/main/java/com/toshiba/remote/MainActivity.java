package com.toshiba.remote;
import android.app.Activity;
import android.hardware.ConsumerIrManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends Activity {
    ConsumerIrManager ir;
    int freq=38000;
    int[] POWER={9000,4500,560,560,560,560,560,1690,560,560,560,560,560,560,560,560,560,560,560,1690,560,1690,560,1690,560,1690,560,560,560,560,560,560,560,560,560,560,560,560,560,560,560,560,560,560,560,1690,560,560,560,560,560,560,560,560,560,560,560,560,560,1690,560,1690,560,1690,560,1690,560,39600};
    int[] VOLUP={9000,4500,560,560,560,560,560,1690,560,560,560,560,560,560,560,560,560,560,560,1690,560,1690,560,1690,560,1690,560,1690,560,560,560,1690,560,560,560,560,560,560,560,560,560,560,560,560,560,560,560,560,560,560,560,560,560,560,560,560,560,560,1690,560,560,560,1690,560,1690,560,1690,560,39600};
    int[] VOLDOWN={9000,4500,560,560,560,560,560,1690,560,560,560,560,560,560,560,560,560,560,560,1690,560,1690,560,1690,560,1690,560,1690,560,560,560,560,560,1690,560,560,560,560,560,560,560,560,560,560,560,560,560,560,560,560,560,560,560,560,560,560,560,560,560,1690,560,560,560,1690,560,1690,560,1690,560,39600};

    protected void onCreate(Bundle b){
        super.onCreate(b);
        setContentView(R.layout.main);
        ir=(ConsumerIrManager)getSystemService(CONSUMER_IR_SERVICE);
        findViewById(R.id.btnPower).setOnClickListener(v->send(POWER));
        findViewById(R.id.btnVolUp).setOnClickListener(v->send(VOLUP));
        findViewById(R.id.btnVolDown).setOnClickListener(v->send(VOLDOWN));
        if(ir!=null&&!ir.hasIrEmitter()) Toast.makeText(this,"Movil sin IR",1).show();
    }

    void send(int[] p){
        if(ir!=null&&ir.hasIrEmitter()){
            ir.transmit(freq,p);
            Toast.makeText(this,"OK",0).show();
        }
    }
}
